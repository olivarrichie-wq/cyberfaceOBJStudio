# Cyberface OBJ Studio (Android starter project)

This is an Android Studio project with a WebView-based OBJ preview tool.

## Build APK without a PC (GitHub Actions)
1. Create a GitHub repository.
2. Upload the **contents** of this ZIP to the repository (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow**, or wait for the first push build.
5. Open the completed workflow run, find **Artifacts**, and download `CyberfaceOBJStudio-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android device.

## Current feature scope
- Android WebView app shell.
- Select OBJ, MTL, and PNG files from Android storage.
- Three.js-based OBJ preview (loads Three.js libraries from the internet).
- Basic display of loaded OBJ mesh in a 3D viewer.

## Important limitations
- This starter project does **not** implement NBA 2K IFF conversion or cross-version IFF porting.
- It is not yet a complete cyberface editor; advanced mesh/material editing and reliable export need further development.
- Internet is required for the 3D preview libraries loaded from the CDN.
- The APK is not prebuilt in this ZIP. GitHub Actions must successfully build it first.
